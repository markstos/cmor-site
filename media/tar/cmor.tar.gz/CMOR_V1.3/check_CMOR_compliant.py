import cdms,os,string,unidata,genutil,Numeric,cdtime


class CMORError(Exception):
    def __init__(self,args=None):
        self.args=args

def manageError(fout,msg,noerror):
    """ Print error message or raise an exception depending on noerror flag)"""

    print >>fout, 'No error is:',noerror
    if noerror:
        raise CMORError,msg
    else:
        print >>fout, '@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%'
        print >>fout, '@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%'
        print >>fout, '@#%@#%@#%@#%@#%           ERROR          %@#%@#%@#%@#%@#%@#%@#%'
        print >>fout, '@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%'
        print >>fout, '@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%'
        print >>fout
        print >>fout, msg
        print >>fout
        print >>fout, '@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%'
        print >>fout, '@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%@#%'
        print >>fout
    return 1


def readTable(table):
    lists_kw=['requested','bounds_requested','z_factors','z_bounds_requested','dimensions','required','ignored','optional']
    f=open(table,'r')
    ln=f.readlines()
    header=1
    gen_attributes={}
    while header:
        l = ln.pop(0)[:-1]
        l=l.strip()
        if l=='' or l[0]=='!':
            continue
        sp=l.split('_entry')
        if len(sp)>1:
            ln.insert(0,l+'\n')
            header=0
            continue
        sp=l.split(':')
        kw=sp[0]
        st=string.join(sp[1:])
        st=st.split('!')[0].strip()
        if st[0]=="'":
            st=st[1:-1]
        if gen_attributes.has_key(kw):
            if isinstance(gen_attributes[kw],str):
                gen_attributes[kw]=[gen_attributes[kw],st]
            else:
                gen_attributes[kw].append(st)
        else:
            gen_attributes[kw]=st
    e={} # entries dictionnary
    while len(ln)>0:
        l = ln.pop(0)
        sp=l.split('_entry:')
        entry_type=sp[0]
        entry=sp[1].strip()
        if not e.has_key(entry_type):
            e[entry_type]={}
        e[entry_type][entry]=getattr(e[entry_type],entry,{})
##         print >>fout, e[entry_type][entry]
        cont=1
        while cont:
            l = ln.pop(0)[:-1]
            l=l.strip()
            if l=='' or l[0]=='!':
                if len(ln)==0:
                    cont=0
                continue
            sp=l.split('_entry:')
            if len(sp)>1:
                ln.insert(0,l+'\n')
                cont=0
            sp=l.split(':')
            kw=sp[0].strip()
            val=string.join(sp[1:],':').split('!')[0].strip()
##             print >>fout, 'dic is:',e[entry_type][entry]
            if e[entry_type][entry].has_key(kw):
                if kw in lists_kw:
                    e[entry_type][entry][kw]=string.join(e[entry_type][entry][kw])
                e[entry_type][entry][kw]+=' '+val
            else:
                e[entry_type][entry][kw]=val
##             print >>fout, 'After:',e[entry_type][entry][kw]
            if kw in lists_kw:
##                 print >>fout, 'splitting:',kw,e[entry_type][entry][kw].split()
                e[entry_type][entry][kw]=e[entry_type][entry][kw].split()
            if len(ln)==0:
                cont=0
    e['general']=gen_attributes
##     for type in e.keys():
##         print >>fout, 'Type:',type
##         for k in e[type].keys():
##             print >>fout, '\t Entry:',k
##             for a in e[type][k].keys():
##                 print >>fout, '\t\t',a,':',e[type][k][a]
    return e


def checkCMOR(fout,file,table,noerror=True,variable=None,from_bounds=None):
    nerr=0
    nwarn=0
    ncheck=0
    print >>fout, 'Reading table:',table
    e=readTable(table)
    Vars=e['variable']
    Axes=e['axis']

    ## Remove that later
##     del(Axes['latitude']['out_name'])
##     del(Axes['longitude']['out_name'])
    
    IPCC_std_vars=[]
    for v in Vars.keys():
        IPCC_std_vars.append(Vars[v].get('out_name',v))
    IPCC_std_axes=[]
    for a in Axes.keys():
        IPCC_std_axes.append(Axes[a].get('out_name',a))
##         if IPCC_std_axes[-1]=='lev' :
##             IPCC_std_axes.pop(-1)
##             IPCC_std_axes.append('eta')
##             Axes[a]['out_name']='eta'
    if variable is None:
        print >>fout, 'Checking file argument',IPCC_std_axes
    if isinstance(file,str):
        fnm=file
        file=cdms.open(file)
    elif isinstance(file,cdms.dataset.CdmsFile):
        fnm=str(file).split('file')[1].split(',')[0].strip()[1:-1]
    else:
        nerr+=manageError(fout, 'Error: You  must pass a file name or cdms file object',noerror)

    if variable is None:
        print >>fout, 'Checking file structure for file:',fnm
        vf=os.path.split(fnm)[-1].split('_')[0]
        if vf not in IPCC_std_vars:
            nerr+=manageError(fout, 'Error '+fnm+' does not start with standard IPCC variable name followed by _',noerror)

        sz=os.path.getsize(fnm)
        print >>fout, 'Checking file size:',sz
        if sz>2**31:
            nerr+=manageError(fout, 'Error file size too large (>2Gb)!',noerror)

        print >>fout, 'Checking that file contains required global attrbutes',e['general'].keys()
        for att in ['institution','source','project_id','table_id','realization','experiment_id']:
            if not hasattr(file,att):
                nerr+=manageError(fout, 'Error: file must have global attribute: '+att,noerror)
            fval=getattr(file,att,'')
            if att=='experiment_id':
                val=e['general'].get('expt_id_ok',None)
                print >>fout, val,fval
                if not fval in val:
                    nerr+=manageError(fout, 'Error experiment_id file attribute must be one of :'+str(val),noerror)
            elif att in ['realization']:
                if isinstance(fval,Numeric.arraytype):
                    if len(fval)>1:
                        nerr+=manageError(fout, 'Error realization attribute must be an integer',noerror)
                    fval=fval[0]
                if not isinstance(fval,int):
                    nerr+=manageError(fout, 'Error realization attribute must be an integer',noerror)
            elif att in ['table_id']:
                print >>fout, '\ttable_id is: ', fval
            else:
                val=e['general'].get(att,None)
                if isinstance(fval,str) : fval=fval.strip().lower()
                if isinstance(val,str) : val=val.strip().lower()
                if val is not None:
                    if isinstance(fval,str):
                        res=string.find(fval,val)
                        if res==-1:
                            res=False
                        else:
                            res=True
                    else:
                        res=fval==val
                        print >>fout, '**************',att,val,fval
                    if not res:
                        nerr+=manageError(fout, 'Error attribute '+att+' must be set to: -'+val+'- +'+fval+'+ '+str(res),noerror)


        for att in ['title','history','references','comment']:
            ncheck+=1
            if not hasattr(file,att):
                nwarn+=1
                print >>fout, '\t\tWarning: It is often helpful to define the global attribute: ',att


        print >>fout, 'Checking that file contains only 1 variable'
        vars=file.listvariable()
        ## removes dims and other complementary vars
        # First bounds
    ##     print >>fout, vars
        vars2=file.listvariable()
        vars3=[]
        vars4=[]
        for v in vars2:
    ##         print >>fout, v
            V=file[v]
            b=getattr(V,'bounds',None)
            if b is not None:
                vars.pop(vars.index(b))
            b=getattr(V,'ancillary_variables',None)
            if b is not None:
                for sp in b.split():
                    if sp.trip() in vars:
                        vars.pop(sp.strip())
            for ax in V.getAxisList():
                b=getattr(ax,'bounds',None)
                if b is not None:
                    if b in vars:
                        vars.pop(vars.index(b))
                    Ab=file[b] # recovers associated bounds with axis
                    f=getattr(Ab,'formula_terms',None)
                    if f is not None:
                        ## figures out the names of formula_terms
                        sp=f.split(':')
    ##                     print >>fout, sp
                        for t in sp:
    ##                         print >>fout, 't is:',t
                            t=t.split()[-1]
    ##                         print >>fout, 'Now it is:',t
                            sp2=f.split(t+':')[1].split()[0]
                            if sp2 in vars:
                                vars3.append(vars.pop(vars.index(sp2)))
                                vars4.append(True)
                f=getattr(ax,'formula_terms',None)
                if f is not None:
                    ## figures out the names of formula_terms
                    sp=f.split(':')
    ##                 print >>fout, sp
                    for t in sp:
    ##                     print >>fout, 't is:',t
                        t=t.split()[-1]
    ##                     print >>fout, 'Now it is:',t
                        sp2=f.split(t+':')[1].split()[0]
                        if sp2 in vars:
                            vars3.append(vars.pop(vars.index(sp2)))
                            vars4.append(False)


            c=getattr(V,'coordinates',None)
            if c is not None and c in vars:
                vars.pop(vars.index(c))

    ##     print >>fout, vars
        if len(vars)!=1:
            nerr+=manageError(fout, 'Error file must contain only 1 variable, you have: '+str(len(vars))+':'+str(vars),noerror)

        var=vars[0]
    fb=False
    if variable is not None:
        var=variable
        fb=from_bounds
        print >>fout, 'Ok user asked to check the following variable:',variable,'with from bounds =',fb
    print >>fout, 'Checking variable name is IPCC compliant'
    if not var in IPCC_std_vars:
        if var in Vars.keys():
            nerr+=manageError(fout, 'Error:'+var+' is not valid, did you mean :'+Vars[var]['out_name']+' ?',noerror)
        else:
            nerr+=manageError(fout, 'Error,  variable name :'+var+' is not IPCC compliant',noerror)
    if variable is None:
        print >>fout, 'Checking that variable name in file matches file indications'
        if not var == vf:
            nerr+=manageError(fout, 'Error, file indicates it stores variable:'+vf+' but actually '+var+' is stored in it',noerror)
    
    V=file[var]

    axes=V.getAxisList()
    hasLat=0
    hasLon=0
    hasTime=0
    hasLevel=0

    ax_dict_name=[]
    for ax in axes:
        print >>fout, 'Checking axis name is valid for:',ax.id
        if not ax.id in IPCC_std_axes:
            if ax.id in Axes.keys():
                ncheck+=1
                nwarn+=1
                print >>fout, '\t\tWarning:'+ax.id+' is not preferred. We suggest you rename it:'+Axes[ax.id]['out_name']
            elif (fb == False) or (fb == True and V.rank()!=2):
                nerr+=manageError(fout, 'Error axis id: '+ax.id+' is not a valid IPCC name',noerror)
        if ax.isLatitude():
            hasLat=1
        if ax.isLongitude():
            hasLon=1
        if ax.isTime():
            hasTime=1
        if ax.isLevel():
            hasLevel=1

    old_ordering=0
    o=V.getOrder(ids=1)
    if old_ordering:
        print >>fout, 'Checking dimensions order'
        if hasTime:
            print >>fout, '\tChecking time position'
            if o[0]=='t':
                o=o[1:]
            else:
                nerr+=manageError(fout, 'Error time must be first dimension your ordering is:'+o,noerror)

        print >>fout, '\tChecking none tzxy dims position'
        sp=o.split('(')
        if len(sp)>1:
            if o[0]!='(':
                nerr+=manageError(fout, 'Error, none zyx dimensions must come right after time dimension, you have:'+o,noerror)
            o=o.split(')')[-1]
        print >>fout, '\tChecking level position'
        if hasLevel:
            if o[0]=='z':
                o=o[1:]
            else:
                nerr+=manageError(fout, 'Error level must be ordered after time your order is:'+o,noerror)
        print >>fout, '\tChecking latitude position'
        if hasLat:
            if o[0]=='y':
                o=o[1:]
            else:
                nerr+=manageError(fout, 'Error latitude must be ordered after time and level your order is:'+o,noerror)
        print >>fout, '\tChecking longitude position'
        if hasLon:
            if o[0]=='x':
                o=o[1:]
            else:
                nerr+=manageError(fout, 'Error longitude must be ordered after time, level and latitude your order is:'+o,noerror)
        
    g=None
    if hasLat and hasLon:
        print >>fout, 'Checking grid'
        g=V.getGrid()
        if not isinstance(g,cdms.grid.AbstractRectGrid):
            nerr+=manageError(fout, 'Error, lat/lon variable ('+var+') must have Rectilinear grids',noerror)

    axes_nmes=Vars[var].get('dimensions',None)

    if axes_nmes is not None:
        print >>fout, 'Checking rest of things on axes'
        axes_nmes=axes_nmes[::-1]
        axes_nmes_for_ordering=Vars[var]['dimensions'][::-1]
        coord=getattr(V,'coordinates',None)
        for nm in axes_nmes:
            req_Att=['standard_name','units','bounds']
            if nm == 'zlevel':
                print >>fout, '\tChecking special case zlevel, i.e',
                tmpax=V.getLevel()
                print>>fout,  tmpax.id,tmpax.standard_name
                for x in Axes.keys():
                    tmp=Axes[x].get('standard_name',None).strip()
                    if tmp is not None and tmp==tmpax.standard_name:
                        nm=x
                        Nm=Axes[x]['out_name']
                        req_Att.append('formula_terms')
                axes_nmes_for_ordering[axes_nmes_for_ordering.index('zlevel')]=nm
            elif not nm in V.getAxisIds():
                try:
                    Nm=Axes[nm]['out_name']
                except:
                    nerr+=manageError(fout, 'Error with axis: '+nm+' not found for variable: '+var, noerror)
            else:
                Nm=nm
            print >>fout, '\tChecking',Nm
            axindx=V.getAxisIndex(Nm)
            val=Axes[nm].get('value',None)
            if val is not None: #singleton dimension ?
                print >>fout, '\t\tSingleton dimension'
                if val is None:
                    nerr+=manageError(fout, 'Error, cannot retrieve needed axis:'+Nm,noerror)
                else:
                    val=float(val)
                    if axindx!=-1:
                        nerr+=manageError(fout, 'Error, singleton dimension '+Nm+' must be defined via coordinates attributes on variable '+var+' not as an axis',noerror)
                    else:
                        print >>fout, '\t\tChecking coordinates attribute exists on '+var
                        aval=getattr(V,'coordinates',None)
                        if aval is None:
                            nerr+=manageError(fout, 'Error singleton dimension must be defined via coordinates attribute',noerror)

                        print >>fout, '\t\tChecking coordinates attribute matches for '+var
                        if aval != Nm:
                            nerr+=manageError(fout, 'Error coordinates atrtribute on '+var+' should be '+Nm+' it is '+aval,noerror)

                        ax=file[Nm]
                        mn,mx=Axes[nm].get('valid_min',None), Axes[nm].get('valid_max',None)
                        print >>fout, '\t\tChecks for value'
                        if ax != val:
                            print >>fout, '\t\t\tNot matching, checking if valid range is defined in table'
                            if mn is None and mx is None:
                                nerr+=manageError(fout, 'Error singleton dimension value for '+Nm+' must be '+str(val),noerror)
                            print >>fout, '\t\t\tChecking if value is within range defined in table'
                            if mn is not None:
                                if mx is not None:
                                    if not( float(mn)<ax<float(mx)):
                                        nerr+=manageError(fout, 'Error, invalid value for singleton dimension '+Nm+': '+str(ax)+' must be between '+mn+' and '+mx,noerror)
                                elif ax<float(mn):
                                    nerr+=manageError(fout, 'Error invalid min for singleton dimension '+Nm+': '+str(ax)+' must be greater than '+mn,noerror)
                            elif ax>float(mx):
                                    nerr+=manageError(fout, 'Error invalid max for singleton dimension '+Nm+': '+str(ax)+' must be less than '+mx,noerror)
                        print >>fout, '\t\tChecking for bounds information'
                        b=getattr(ax,'bounds',None)
                        bv=Axes[nm].get('bounds_values',None)
                        if bv is not None:
                            print >>fout, '\t\t\tBounds information defined in table, checking vs file'
                            bv=bv.split()
                            bv=float(bv[0]),float(bv[1])
                            if b is not None:
                                print >>fout, '\t\t\tBounds information defined in file, checking if matches'
                                abv=file[b]
                                ncheck+=1
                                if abv[0]!=bv[0] or abv[1]!=bv[1]:
                                    nwarn+=1
                                    print >>fout, '\t\t\t\tWarning: bounds_value for singleton dimension '+Nm+': '+str(abv)+' do not match requested bounds:'+str(bv)
                            else:
                                nerr+=manageError(fout, 'Error singleton dimension: '+Nm+' bounds required',noerror)
                        else:
                            ncheck+=1
                            if b is not None:
                                nwarn+=1
                                print >>fout, '\t\t\t\tWarning: singleton dimension: '+Nm+' bounds should not be included'

                axes_nmes_for_ordering.pop(0)
                continue # singleton dimension checked no need to continue further

            if axindx==-1:
                nerr+=manageError(fout, 'Error: Variable '+var+' should have an axis called '+Axes[Nm],noerror)
            ax=V.getAxis(axindx)
            print >>fout, '\t\tChecking that dimension order is positioned:',axes_nmes_for_ordering.index(nm)+1,axes_nmes
            if axindx!=axes_nmes_for_ordering.index(nm):
                nerr+=manageError(fout, 'Error in ordering for dimension '+nm+' position is: '+str(axindx)+' but it should be: '+str(axes_nmes_for_ordering.index(nm)),noerror)
            if ('cell_bounds' in Axes[nm].get('ignored',[])) or ('cell_bounds' in Axes[nm].get('optional',[])):
                req_Att.pop(req_Att.index('bounds'))
            if 'units' in Axes[nm].get('ignored',[]) or 'units' in Axes[nm].get('optional',[]):
                try:
                    req_Att.pop(req_Att.index('units'))
                except:
                    pass
            ## Ok here we're trying to do the region thing, i.e coordinate attribute exist
            docoord=False
            if coord is not None:
                nax=file[coord]
                if ax.id in nax.getAxisIds():
                    oldax=ax
                    ax=nax
                    docoord=True
            print >>fout, '\t\tChecking if required attributes are set:',
            for r in req_Att:
                print >>fout, r,
                val=getattr(ax,r,None)
                if val is None:
                    print >>fout
                    nerr+=manageError(fout, 'Error, attribute '+r+' is required for axis '+ax.id,noerror)
                elif r!='units':
                    good_val=Axes[nm].get(r,None)
                    if good_val is not None:
                        if val!=good_val:
                            nerr+=manageError(fout, 'Error, axis attribute '+r+' should be: '+str(good_val)+' but is:'+str(val),noerror)
            print >>fout
            if not 'units' in Axes[nm].get('ignored',[]):
                if not 'units' in Axes[nm].get('optional',[]) or ('units' in Axes[nm].get('optional',[]) and hasattr(ax,'units')):
                    if not ax.isTime():
                        print >>fout, '\t\tChecking units',ax.units
                        u1=genutil.udunits(1,ax.units)
                        try:
                            u2=u1.to(Axes[nm]['units'])
                            if u2.value!=1:
                                nerr+=manageError(fout, 'Error, units:'+ax.units+' are not compatible with required:'+Axes[nm]['units'],noerror)
                        except:
                            nerr+=manageError(fout, 'Error, units:'+ax.units+' are not compatible with required:'+Axes[nm]['units'],noerror)
                    else:
                        print >>fout, '\t\tChecking units',ax.units
                        try:
                            u=cdtime.reltime(1,ax.units)
                        except:
                            nerr+=manageError(fout, 'Error, invalid time units:'+ax.units+', should be in the form: "'+Axes[nm]['units']+'"',noerror)
                        c=ax.calendar
                        if c=='365_day':
                            c=cdtime.NoLeapCalendar
                        else:
                            c=ax.getCalendar()
                        print >>fout, '\t\tView First and Last times:\t',ax.asComponentTime(c)[0],'\t',ax.asComponentTime(c)[-1]
                        tmpbnds=ax.getBounds()
                        if tmpbnds is not None:
                            c=ax.calendar
                            if c=='365_day':
                                c=cdtime.NoLeapCalendar
                            else:
                                c=ax.getCalendar()
                            print >>fout, '\t\tView Bounds for first time:\t',cdtime.reltime(tmpbnds[0,0],ax.units).tocomp(c),'\t',cdtime.reltime(tmpbnds[0,1],ax.units).tocomp(c)
                            print >>fout, '\t\tView Bounds for last time:\t',cdtime.reltime(tmpbnds[-1,0],ax.units).tocomp(c),'\t',cdtime.reltime(tmpbnds[-1,1],ax.units).tocomp(c)
                        else:
                            print >>fout,'\t\tNo Bounds for time'
                            

            tp=Axes[nm].get('type','double')
            print >>fout, '\t\tChecking axis is type',tp

            if tp == 'double' : tp='d'
            elif tp == 'real' : tp='f'
            elif tp == 'character' : tp='c'
            elif tp == 'integer' : tp='l'
            else:
                nerr+=manageError(fout, 'Error, encountered unknown type:'+tp,noerror)
            if ax.typecode()!=tp:
                nerr+=manageError(fout, 'Error required typecode for '+Nm+' should be '+tp+' not '+ax.typecode(),noerror)

            if ax.isLongitude():
                print >>fout, '\t\tChecking for axis attribute'
                a=getattr(ax,'axis',None)
                if a is None:
                    nerr+=manageError(fout, 'Error, longitude axis must have associated axis attribute',noerror)
                if a!='X':
                    nerr+=manageError(fout, 'Error, longitude axis must have associated axis attribute set to X not: '+a,noerror)
                print >>fout, '\t\tChecking name'
                if not ax.id in ['lon','longitude']:
                    nerr+=manageError(fout, 'Error, longitude axis name must be longitude or lon (prefered) not: '+ax.id,noerror)
##                 else:
##                     ncheck+=1
##                     if ax.id=='longitude':
##                         nwarn+=1
##                         print >>fout, '\t\t\tWarning we recomend longitude axis name to be: "lon"'
                print >>fout, '\t\tChecking that the first point is >= 0'
                if ax[0]<0:
                    nerr+=manageError(fout, 'Error first longitude must be >= 0 degrees_east',noerror)
                print >>fout, '\t\tChecking that the longitude are in degrees (not rads)'
                min,max=genutil.minmax(ax[:])
                if max-min<6.3:
                    nerr+=manageError(fout, 'Error longitude must be stored in degree span is:'+str(max-min)+' looks like rad',noerror)
            elif ax.isLatitude():
                print >>fout, '\t\tChecking for axis attribute'
                a=getattr(ax,'axis',None)
                if a is None:
                    nerr+=manageError(fout, 'Error, latitude axis must have associated axis attribute',noerror)
                if a!='Y':
                    nerr+=manageError(fout, 'Error, latitude axis must have associated axis attribute set to Y not: '+a,noerror)
                print >>fout, '\t\tChecking name'
                if not ax.id in ['lat','latitude']:
                    nerr+=manageError(fout, 'Error, latitude axis name must be latitude or lat (prefered) not: '+ax.id,noerror)
##                 else:
##                     ncheck+=1
##                     if ax.id=='latitude':
##                         nwarn+=1
##                         print >>fout, '\t\t\tWarning we recomend latitude axis name to be: "lat"'
                print >>fout, '\t\tChecking that the latitude are in degrees (not rads)'
                min,max=genutil.minmax(ax[:])
                if max-min<3.2:
                    nerr+=manageError(fout, 'Error latitude must be stored in degree span is:'+str(max-min)+' looks like rad',noerror)
            elif ax.isTime() and len(ax[:])>1:
                print >>fout, '\t\tChecking for axis attribute'
                a=getattr(ax,'axis',None)
                if a is None:
                    nerr+=manageError(fout, 'Error, time axis must have associated axis attribute',noerror)
                if a!='T':
                    nerr+=manageError(fout, 'Error, time axis must have associated axis attribute set to T not: '+a,noerror)
                print >>fout, '\t\tView calendar attribute: ',
                c=getattr(ax,'calendar',None)
                if c is None:
                    print >>fout
                    nerr+=manageError(fout, 'Error, calendar attribute must be defined on time axis',noerror)
                else:
                    print >>fout, c
                    
            elif ax.isLevel():
                print >>fout, '\t\tChecking for axis attribute'
                a=getattr(ax,'axis',None)
                if a is None:
                    nerr+=manageError(fout, 'Error, vertical axis must have associated axis attribute',noerror)
                if a!='Z':
                    nerr+=manageError(fout, 'Error, vertical axis must have associated axis attribute set to Z not: '+a,noerror)
                print >>fout, '\t\tChecking that level are stored with first level closest from surface'
                ## ???
                print >>fout, '\t\tChecking positive attribute'
                p=getattr(ax,'positive',None)
                if nm != 'zlevel':
                    ncheck+=1
                if p is None:
                    if nm == 'zlevel':
                        nerr+=manageError(fout, 'Error vertical dimensions must have positive attribute',noerror)
                    else:
                        nwarn+=1
                        print >>fout, 'Warning: The "positive" attribute should be defined for vertical dimensions.'
                        
                elif not p in ['up','down']:
                    nerr+=manageError(fout, 'Error positive attribute on vertical dimension must be be up or down not: '+p,noerror)
                if hasattr(ax,'formula_terms'):
                    ncheck+=1
                    if not hasattr(ax,'formula'):
                        print >>fout, '\t\t\tWarning: level dimension has no attribute formula!'
                        nwarn+=1
                    ncheck+=1
                    print >>fout, '\t\tChecking that formula terms variables are stored'
                    ft=getattr(ax,'formula_terms',None)
                    ## figures out the names of formula_terms
                    sp=ft.split(':')
    ##                 print >>fout, sp
                    for t in sp:
    ##                     print >>fout, 't is:',t
                        t=t.split()[-1]
    ##                     print >>fout, 'Now it is:',t
                        sp2=ft.split(t+':')[1].split()[0]
                        if not sp2 in file.variables.keys():
                            nerr+=manageError(fout, 'Error, formula_terms attribute indicates variable '+sp2+' should be stored in file',noerror)

            if not docoord:
                dirc=Axes[nm].get('stored_direction','increasing').lower()
                if dirc == 'increasing':
                    func=Numeric.greater
                elif dirc == 'decreasing':
                    func=Numeric.less
                else:
                    nerr+=manageError(fout, 'Error, unknown value for stored_direction:',dirc,noerror)
                print >>fout, '\t\tChecking that axis is stored '+dirc+'ly'
                prev=ax[0]
                for a in ax[1:]:
                    if not func(a,prev):
                        nerr+=manageError(fout, 'Error, axis values for '+Nm+' must be stored:'+dirc+'ly',noerror)
                    prev=a
                Mn,Mx=genutil.minmax(ax[:])
                mn=Axes[nm].get('valid_min',None)
                if mn is not None:
                    print >>fout, '\t\tChecking valid min',mn
                    if Mn<float(mn):
                        nerr+=manageError(fout, 'Error axis '+Nm+' invalid min:'+str(Mn)+' cannot be less than:'+mn,noerror)
                mx=Axes[nm].get('valid_max',None)
                if mx is not None:
                    print >>fout, '\t\tChecking valid max',mx
                    if Mx>float(mx):
                        nerr+=manageError(fout, 'Error axis '+Nm+' invalid max:'+str(Mx)+' cannot be greater than:'+mx,noerror)
            rq=Axes[nm].get('requested',None)
            if rq is not None:
                print >>fout, '\t\tChecking that requested values are present:',rq
                tol=float(Axes[nm].get('tol_on_requests',1.e-3))
                for ir in range(len(rq)):
                    r=rq[ir]
                    found=0
                    if docoord:
                        for iv in range(len(ax[:])):
                            v=ax[iv]
                            st=''
                            for vv in v:
                                st+=str(vv)
                            if r.strip().lower()==st.strip().lower():
                                found=1
                                ifound=iv
                                break
                    else:
                        r=float(r)
                        for iv in range(len(ax[:])):
                            v=ax[iv]
                            if abs(v-r)<tol:
                                found=1
                                ifound=iv
                                break
                    if found==0:
                        nerr+=manageError(fout, 'Error on axis '+Nm+' requested value '+str(r)+' not found',noerror)
                    elif ifound!=ir:
                        nerr+=manageError(fout, 'Error on axis '+Nm+' requested value "'+str(r)+'" present but not in the correct order, it is at position '+str(ifound)+' but should be ordered '+str(ir)+' ( actual order should be: '+str(rq)+' )',noerror)

            if 'bounds' in req_Att:
                print >>fout, '\t\tChecking for bounds'
                b=getattr(ax,'bounds',None)
                if b is None:
    ##                 if ax.isLevel():
    ##                     print >>fout, '\t\t\tWarning level dimension has no bounds!'
    ##                     nwarn+=1
    ##                     ncheck+=1
    ##                 if ax.isTime():
    ##                     print >>fout, '\t\t\tWarning time dimension has no bounds!'
    ##                     nwarn+=1
    ##                     ncheck+=1
    ##                 else:
                        nerr+=manageError(fout, 'Error dimension:'+Nm+' has no associated bounds',noerror)
                else:
                    print >>fout, '\t\tChecking that defined bounds variable is in file'
                    if not b in file.variables.keys():
                        nerr+=manageError(fout, 'Error dimension '+Nm+' associated bounds are defined to be '+b+' but the variable is not present in file',noerror)
                    if ax.isTime():
                        interv = Axes[nm].get('interval',None)
                        tinterv = e['general'].get('approx_interval',None)
                        if float(tinterv) == 30. and interv!=0:
                            print >>fout, '\t\tChecking that bounds are at beg and end of month'
                            bnds=ax.getBounds()
                            for ib in range(len(ax[:])):
                                b=bnds[ib]
                                c=ax.calendar
                                if c=='365_day':
                                    c=cdtime.NoLeapCalendar
                                else:
                                    c=ax.getCalendar()

                                beg=cdtime.reltime(b[0],ax.units).tocomp(c)
                                end=cdtime.reltime(b[1],ax.units).tocomp(c)
                                mid=cdtime.reltime(ax[ib],ax.units).tocomp(c)
                                if beg.month!=mid.month:
                                    nerr+=manageError(fout, 'Error at time value: '+str(mid)+' (index: '+str(ib)+' ) bounds do not start in the same month than time value: '+str(beg),noerror)
                                if beg.cmp(cdtime.comptime(beg.year,beg.month))!=0:
                                    nerr+=manageError(fout, 'Error at time value: '+str(mid)+' (index: '+str(ib)+' ) bounds do not start at begining of the month: '+str(beg),noerror)
                                if end.month!=mid.add(1,cdtime.Month).month:
                                    nerr+=manageError(fout, 'Error at time value: '+str(mid)+' (index: '+str(ib)+' ) bounds do not end in the following month than time value: '+str(end),noerror)
                                if end.cmp(beg.add(1,cdtime.Month))!=0:
                                    nerr+=manageError(fout, 'Error at time value: '+str(mid)+' (index: '+str(ib)+' ) bounds do not end at end of the month: '+str(end),noerror)

    print >>fout, 'Checking variable:',var
    tmp=['units']
    if Vars[var].get('standard_name',None) is not None:
        tmp.append('standard_name')
    for o in Vars[var].get('optional',[]):
        if o in tmp:
            tmp.pop(tmp.index(o))
    print >>fout, 'Vars att:',Vars[var]
    print >>fout, '\tChecking if required attributes are set:',
    for r in tmp:
        print >>fout, r,
        if getattr(V,r,None) is None:
            print >>fout
            nerr+=manageError(fout, 'Error, attribute '+r+' is required but not set for var '+var,noerror)
        elif r!='units' and r.strip().lower()!='standard_name':
            good_val=Vars[var].get(r,None)
            if good_val is not None:
                if val!=good_val:
                    nerr+=manageError(fout, 'Error, variable attribute '+r+' should be: '+str(good_val)+' but is:'+str(val),noerror)
    print >>fout
    tp=Vars[V.id].get('type','real')
    print >>fout, '\tChecking Variable typecode is',tp
    if tp == 'double' : tp='d'
    elif tp == 'real' : tp='f'
    elif tp == 'character' : tp='c'
    elif tp == 'integer' : tp='l'
    else:
        nerr+=manageError(fout, 'Error, encountered unknown type:'+tp,noerror)
    if V.typecode()!=tp:
        nerr+=manageError(fout, 'Error variable typecode must be '+tp+', it is:'+V.typecode(),noerror)

    if 'units' in tmp:
        print >>fout, '\tChecking defined units'
        U1=unidata.udunits(1,V.units)
        try:
            U2=U1.to(Vars[var]['units'])
            if U2.value!=1:
                nerr+=manageError(fout, 'Error variable units:'+V.units+' do not match IPCC units:'+Vars[var]['units']+'\n'+\
                      '1 '+V.units+' is actually :'+str(U2),noerror)
        except:
            nerr+=manageError(fout, 'Error variable units:'+V.units+' do not match IPCC units:'+Vars[var]['units'],noerror)
    if 'standard_name' in Vars[var].keys():
        print >>fout, '\tChecking standard name (case independent)'
        if getattr(V,'standard_name','').lower().strip()!=Vars[var]['standard_name']:
            nerr+=manageError(fout, 'Error, standard_name for '+var+' should be:'+Vars[var]['standard_name'],noerror)

    if hasattr(V,'_FillValue'):
        print >>fout, '\tChecking for _FillValue'
        tp=Vars[var].get('type','real')
        if tp == 'double' :
            tpv=Numeric.array(float(e['general'].get('double_missing_value',1.e20)),'d')
        elif tp == 'real' :
            tpv=Numeric.array(float(e['general'].get('missing_value',1.e20)),'f')
        elif tp == 'integer' :
            tpv=Numeric.array(int(e['general'].get('integer_missing_value',-192837)),'i')
        else:
            nerr+=manageError(fout, 'Error, encountered unknown type:'+tp,noerror)

        if getattr(V,'_FillValue')!=tpv:
            nerr+=manageError(fout, 'Error _FillValue must be '+str(tpv)+' (in the typecode of variable)',noerror)

    print >>fout, '\tChecking for warnings'
    if hasattr(V,'_FillValue'):
        ncheck+=1        
        if not hasattr(V,'missing_value'):
            print >>fout, '\t\tWarning: You defined _FillValue. We recommend you also define missing_value'
            nwarn+=1
        elif V.missing_value!=V._FillValue:
            nerr+=manageError(fout, 'Error missing_value and _FillValue attributes are different',noerror)
    if variable is None:
        cm=Vars[var].get('cell_methods',[])
        if cm!=[]:
            print >>fout, '\tChecking for cell_methods: ',
            if not hasattr(V,'cell_methods'):
                print >> fout
                nerr+=manageError(fout, 'Error Variable '+var+' should have "cell_methods" attribute',noerror)
            else:
                 print >> fout,V.cell_methods
               
            cmv=getattr(V,'cell_methods','')
            sp=cm.split('(')
            cm=sp[0]
            for s in sp[1:]:
                cm+=s.split(')')[-1]
            sp=cmv.split('(')
            cmv=sp[0]
            for s in sp[1:]:
                cmv+=s.split(')')[-1]
            sp=cm.split(':')
            dic={}
            kw=sp[0].strip()
            for s in sp[1:]:
                dic[kw]=s.split()[0].strip()
                kw=s.split()[-1].strip()
            sp=cmv.split(':')
            dicv={}
            kw=sp[0].strip()
            for s in sp[1:]:
                dicv[kw]=s.split()[0].strip()
                kw=s.split()[-1].strip()
            for kw in dic.keys():
                if not kw in dicv.keys():
                    nerr+=manageError(fout, 'Error cell_methods must include '+kw+' defined (to: '+dic[kw]+' )',noerror)
                elif not dicv[kw]==dic[kw]:
                    nerr+=manageError(fout, 'Error cell_method: '+kw+' definition does not match table, it is :'+dicv[kw]+' but should be: '+dic[kw],noerror)
        for att in ['original_name','history','original_units','long_name','comment']:
            ncheck+=1
            if not hasattr(V,att):
                nwarn+=1
                print >>fout, '\t\tWarning: It is often helpful to define the variable attribute: ',att
        print >>fout, '\n**********************************************************************************************\n'
        print >>fout, 'Done with main variable moving on to sub-variables'
        for iv in range(len(vars3)):
            print >>fout, '\n----------------------------------------------------------------------------------------------\n'
            v=vars3[iv]
            fb=vars4[iv]
            print >>fout, 'Now Checking sub-variable:',v
            print >>fout, '\n----------------------------------------------------------------------------------------------\n'
            nwarn_add,ncheck_add,nerr_add=checkCMOR(fout,file,table,variable=v,from_bounds=fb,noerror=noerror)
            nwarn+=nwarn_add
            ncheck+=ncheck_add
            nerr+=nerr
        print >>fout, '%d warnings issued out of %d checked for (%5.2f%%)' % (nwarn,ncheck,float(nwarn)/ncheck*100)
        if nerr!=0:
            raise CMORError, str(nerr)+' CMOR errors were raise, please check output and correct your file !!!!'
        
    return nwarn,ncheck,nerr
            
if __name__=='__main__':
    import getopt,sys

    var='ta'
    var='mrsos'
    var='cl'
    var='snw'

    file='/pcmdi/ktaylor/pcmdi/IPCC_data/FRSGC/'+var+'_A1.nc'
    table='Tables/IPCC/IPCC_table_A1'
    noerror=True
    out='screen'
    
    help="""
    Verify that a file is CMOR compliant

    Usage:
    """+sys.argv[0]+""" [--help] [-f /--file=filename] [-t /--table=tablename]
    Where:
      --help/-?/-h print >>fout, this message
      --table/-t : specify table file to use
      --file/-f specify file to check
      --noerror/-e do not allow error on/off (default "on")
      --out/-o screen or file name (file sends to inputfile.out)
      """

    kw=['file=','help','table=','noerror=','out=']
    cmd='f:h?t:e:o:'
    
    opt=getopt.getopt(sys.argv[1:],cmd,kw)

    if opt[1]!=[]:
        file=opt[1][-1]
    for o,p in opt[0]:
        if o in ['--file','-f']:
            file=p
        if o in ['--table','-t']:
            table=p
        if o in ['--help','-h','-?']:
            print help
            sys.exit()
        if o in ['--noerror','-e']:
            if p.lower() in ['off','0']:
                noerror=False
            elif p.lower() in ['on','1']:
                noerror=True
        if o in ['--out','-o']:
            out=p

    print 'File is:',file,string.find(file,'*')
    if os.path.isdir(file):
        files=os.popen('ls '+file+'/*.nc').readlines()
    elif string.find(file,'*')>=0:
        files=os.popen('ls '+file).readlines()
    else:
        files=[file]
    print 'Files:',files
    for file in files:
        print 'Dealing with ',file.strip()
        if out.lower()=='screen':
            fout=sys.stdout
        elif out.lower()=='file':
            fout=string.join(file.strip().split('.')[:-1],'.')+'.out'
            fout=open(fout,'w')
        else:
            fout=open(out,'w')
        if noerror:
            checkCMOR(fout,file.strip(),table,noerror)
        else:
            try:
                checkCMOR(fout,file.strip(),table,noerror)
            except Exception,err:
                print err
           
